package com.zoy.java.zoyjavamultithreadlearning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoyJavaMultiThreadLearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoyJavaMultiThreadLearningApplication.class, args);
	}

}
